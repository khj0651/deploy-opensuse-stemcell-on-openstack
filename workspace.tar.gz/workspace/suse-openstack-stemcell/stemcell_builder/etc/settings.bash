# parameters for `bosh_users`
bosh_users_password=c1oudc0w
