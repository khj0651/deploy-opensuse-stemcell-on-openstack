module Bosh
  module Stemcell
  end
end
