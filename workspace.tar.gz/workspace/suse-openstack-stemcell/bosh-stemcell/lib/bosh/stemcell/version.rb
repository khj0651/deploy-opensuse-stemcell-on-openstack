module Bosh
  module Stemcell
    VERSION = '0.0.0'
  end
end
