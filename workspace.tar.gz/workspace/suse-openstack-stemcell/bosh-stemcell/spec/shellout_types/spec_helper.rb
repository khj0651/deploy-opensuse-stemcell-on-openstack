require 'rspec'
require 'rspec/its'
require 'shellout_types/chroot'

ShelloutTypes::Chroot.chroot_dir = '/tmp/ubuntu-chroot'
