require 'spec_helper'
require 'bosh/stemcell'

describe Bosh::Stemcell do
  it { should be_a(Module) }
end
