require 'spec_helper'

describe 'CentOS 7 OS image', os_image: true do
  it_behaves_like 'every OS image'
  it_behaves_like 'an os with ntpdate'
  it_behaves_like 'a CentOS or RHEL based OS image'
  it_behaves_like 'a systemd-based OS image'
  it_behaves_like 'a Linux kernel 3.x based OS image'
  it_behaves_like 'a Linux kernel module configured OS image'

  context 'installed by base_centos' do
    describe file('/etc/locale.conf') do
      it { should be_file }
      it('uses US english, UTF8 charset') { expect(subject.content).to match /en_US\.UTF-8/}
    end

    %w(
      centos-release
      epel-release
    ).each do |pkg|
      describe package(pkg) do
        it { should be_installed }
      end
    end
  end

  context 'installed by base_centos_packages' do
    %w(
      bison
      bzip2-devel
      cloud-utils-growpart
      cmake
      cronie-anacron
      curl
      dhclient
      e2fsprogs
      flex
      gdb
      gdisk
      glibc-static
      iptables
      libcap-devel
      libuuid-devel
      libxml2
      libxml2-devel
      libxslt
      libxslt-devel
      lsof
      NetworkManager
      net-tools
      nmap-ncat
      openssh-server
      openssl
      openssl-devel
      parted
      psmisc
      readline-devel
      rpm-build
      rpmdevtools
      rsync
      rsyslog
      rsyslog-relp
      rsyslog-gnutls
      rsyslog-mmjsonparse
      runit
      strace
      sudo
      sysstat
      systemd
      tcpdump
      traceroute
      unzip
      wget
      zip
    ).each do |pkg|
      describe package(pkg) do
        it { should be_installed }
      end
    end

    describe file('/usr/sbin/ifconfig') do
      it { should be_executable }
    end
  end

  context 'installed by system_grub' do
    describe package('grub2-tools') do
      it { should be_installed }
    end
  end

  context 'required initramfs modules' do
    describe command("/usr/lib/dracut/skipcpio /boot/initramfs-3.10.*.el7.x86_64.img | zcat | cpio -t | grep '/lib/modules/3.10.*.el7.x86_64'") do

      modules = [
        #ata
          'ata_generic', 'pata_acpi',
        #block
          'floppy', 'loop', 'brd',
        #xen
          'xen-blkfront',
        #hv
          'hv_vmbus','hv_storvsc', 'hv_vmbus',
        #virtio
          'virtio_blk', 'virtio_net', 'virtio_pci', 'virtio_scsi',
        #vmware fusion
          'mptspi', 'mptbase', 'mptscsih','mpt2sas', 'mpt3sas',
        #scsci
          '3w-9xxx',
          '3w-sas',
          'aic79xx',
          'arcmsr',
          'bfa',
          'fnic',
          'hpsa',
          'hptiop',
          'initio',
          'isci',
          'libsas',
          'lpfc',
          'megaraid_sas',
          'mtip32xx',
          'mvsas',
          'mvumi',
          'nvme',
          'pm80xx',
          'pmcraid',
          'qla2xxx',
          'qla4xxx',
          'raid_class',
          'stex',
          'sx8',
          'vmw_pvscsi',
        #fs
          'cachefiles',
          'cifs',
          'cramfs',
          'dlm',
          'libore',
          'fscache',
          'grace',
          'nfs_acl',
          'fuse',
          'gfs2',
          'isofs',
          'nfs',
          'nfsd',
          'nfsv3',
          'nfsv4',
          'overlay',
          'ramoops',
          'squashfs',
          'udf',
          'btrfs',
          'ext4',
          'jbd2',
          'mbcache',
          'xfs'
      ]

      modules.each do |foo|
        its (:stdout) { should match(/\/#{foo}\.ko/) }
      end
    end
  end

  context 'overriding control alt delete (stig: V-38668)' do
    describe file('/etc/systemd/system/ctrl-alt-del.target') do
      it { should be_file }
      it('remarks on the escaping') { expect(subject.content).to match '# escaping ctrl alt del' }
    end
  end

  context 'official Centos gpg key is installed (stig: V-38476)' do
    describe command('rpm -qa gpg-pubkey* 2>/dev/null | xargs rpm -qi 2>/dev/null') do
      its (:stdout) { should include('CentOS 7 Official Signing Key') }
    end
  end

  context 'ensure sendmail is removed (stig: V-38671)' do
    describe command('rpm -q sendmail') do
      its (:stdout) { should include ('package sendmail is not installed')}
    end
  end

  context 'ensure cron is installed and enabled (stig: V-38605)' do
    describe package('cronie') do
      it('should be installed') { should be_installed }
    end

    describe file('/etc/systemd/system/default.target') do
      it { should be_file }
      its(:content) { should match /^Requires=multi-user\.target/ }
    end

    describe file('/etc/systemd/system/multi-user.target.wants/crond.service') do
      it { should be_file }
      its(:content) { should match /^ExecStart=\/usr\/sbin\/crond/ }
    end
  end

  # V-38498 and V-38495 are the package defaults and cannot be configured
  context 'ensure auditd is installed but not enabled (stig: V-38628) (stig: V-38631) (stig: V-38632) (stig: V-38498) (stig: V-38495)' do
    describe package('audit') do
      it { should be_installed }
    end
  end

  context 'ensure xinetd is not installed nor enabled (stig: V-38582)' do
    describe package('xinetd') do
      it('should not be installed') { should_not be_installed }
    end

    describe file('/etc/systemd/system/multi-user.target.wants/xinetd.service') do
      it { should_not be_file }
    end
  end

  context 'ensure ypbind is not installed nor enabled (stig: V-38604)' do
    describe package('ypbind') do
      it('should not be installed') { should_not be_installed }
    end

    describe file('/etc/systemd/system/multi-user.target.wants/ypbind.service') do
      it { should_not be_file }
    end
  end

  context 'ensure ypserv is not installed (stig: V-38603)' do
    describe package('ypserv') do
      it('should not be installed') { should_not be_installed }
    end
  end

  context 'ensure audit package file have correct permissions (stig: V-38663)' do
    describe command('rpm -V audit | grep ^.M') do
      its (:stdout) { should be_empty }
    end
  end

  context 'ensure audit package file have correct owners (stig: V-38664)' do
    describe command("rpm -V audit | grep '^.....U'") do
      its (:stdout) { should be_empty }
    end
  end

  context 'ensure audit package file have correct groups (stig: V-38665)' do
    describe command("rpm -V audit | grep '^......G'") do
      its (:stdout) { should be_empty }
    end
  end

  context 'ensure audit package file have unmodified contents (stig: V-38637)' do
    # ignore auditd.conf, and audit.rules since we modify these files in
    # other stigs
    describe command("rpm -V audit | grep -v 'auditd.conf' | grep -v 'audit.rules' | grep -v 'syslog.conf' | grep '^..5'") do
      its (:stdout) { should be_empty }
    end
  end

  context 'PAM configuration' do
    describe file('/usr/lib64/security/pam_cracklib.so') do
      it { should be_file }
    end

    describe file('/etc/pam.d/system-auth') do
      it 'must prohibit the reuse of passwords within twenty-four iterations (stig: V-38658)' do
        expect(subject.content).to match /password.*pam_unix\.so.*remember=24/
      end

      it 'must prohibit new passwords shorter than 14 characters (stig: V-38475)' do
        expect(subject.content).to match /password.*pam_unix\.so.*minlen=14/
      end

      it 'must use the cracklib library to set correct password requirements (CIS-9.2.1)' do
        expect(subject.content).to match /password.*pam_cracklib\.so.*retry=3.*minlen=14.*dcredit=-1.*ucredit=-1.*ocredit=-1.*lcredit=-1/
      end
    end
  end

  context 'display the number of unsuccessful logon/access attempts since the last successful logon/access (stig: V-51875)' do
    describe file('/etc/pam.d/system-auth') do
      its(:content){ should match /session     required      pam_lastlog\.so showfailed/ }
    end
  end

  context 'gpgcheck must be enabled (stig: V-38483)' do
    describe file('/etc/yum.conf') do
      its(:content) { should match /^gpgcheck=1$/ }
    end
  end

  context 'installed by bosh_sysctl' do
    describe file('/etc/sysctl.d/60-bosh-sysctl.conf') do
      it { should be_file }

      it 'must limit the ability of processes to have simultaneous write and execute access to memory. (only centos) (stig: V-38597)' do
        expect(subject.content).to match /^kernel.exec-shield=1$/
      end
    end
  end

  context 'ensure net-snmp is not installed (stig: V-38660) (stig: V-38653)' do
    describe package('net-snmp') do
      it { should_not be_installed }
    end
  end

  context 'ensure rpcbind is not enabled (CIS-6.7)' do
    describe file('/etc/init/rpcbind-boot.conf') do
      it { should_not be_file }
    end

    describe file('/etc/init/rpcbind.conf') do
      it { should_not be_file }
    end
  end

  describe 'ensure nfs is not enabled (CIS-6.7)' do
    describe command("ls /etc/rc*.d/ | grep S*nfs-kernel-server") do
      its (:stdout) { should be_empty }
    end
  end

  context 'restrict access to the su command CIS-9.5' do
    describe command('grep "^\s*auth\s*required\s*pam_wheel.so\s*use_uid" /etc/pam.d/su') do
      it('exits 0') { expect(subject.exit_status).to eq(0) }
    end
    describe user('vcap') do
      it { should exist }
      it { should be_in_group 'wheel' }
    end
  end

  describe 'logging and audit startup script' do
    describe file('/var/vcap/bosh/bin/bosh-start-logging-and-auditing') do
      it { should be_file }
      it { should be_executable }
      it('starts auditd') { expect(subject.content).to match('service auditd start') }
    end
  end

  describe 'allowed user accounts' do

    describe file('/etc/passwd') do
      passwd_match_raw = <<HERE
root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/sbin/nologin
daemon:x:2:2:daemon:/sbin:/sbin/nologin
adm:x:3:4:adm:/var/adm:/sbin/nologin
lp:x:4:7:lp:/var/spool/lpd:/sbin/nologin
sync:x:5:0:sync:/sbin:/bin/sync
shutdown:x:6:0:shutdown:/sbin:/sbin/shutdown
halt:x:7:0:halt:/sbin:/sbin/halt
mail:x:8:12:mail:/var/spool/mail:/sbin/nologin
operator:x:11:0:operator:/root:/sbin/nologin
games:x:12:100:games:/usr/games:/sbin/nologin
ftp:x:14:50:FTP User:/var/ftp:/sbin/nologin
nobody:x:99:99:Nobody:/:/sbin/nologin
systemd-network:x:192:192:systemd Network Management:/:/sbin/nologin
dbus:x:81:81:System message bus:/:/sbin/nologin
polkitd:x:999:998:User for polkitd:/:/sbin/nologin
rpc:x:32:32:Rpcbind Daemon:/var/lib/rpcbind:/sbin/nologin
abrt:x:173:173::/etc/abrt:/sbin/nologin
libstoragemgmt:x:998:997:daemon account for libstoragemgmt:/var/run/lsm:/sbin/nologin
tcpdump:x:72:72::/:/sbin/nologin
chrony:x:997:996::/var/lib/chrony:/sbin/nologin
ntp:x:38:38::/etc/ntp:/sbin/nologin
tss:x:59:59:Account used by the trousers package to sandbox the tcsd daemon:/dev/null:/sbin/nologin
sshd:x:74:74:Privilege-separated SSH:/var/empty/sshd:/sbin/nologin
vcap:x:1000:1000:BOSH System User:/home/vcap:/bin/bash
syslog:x:996:993::/home/syslog:/sbin/nologin
HERE
      passwd_match_lines = passwd_match_raw.split(/\n+/)

      its(:content_as_lines) { should match_array(passwd_match_lines)}
    end

    describe file('/etc/shadow') do
      shadow_match_raw = <<HERE
root:(.+):\\d{5}:0:99999:7:::
bin:\\*:\\d{5}:0:99999:7:::
daemon:\\*:\\d{5}:0:99999:7:::
adm:\\*:\\d{5}:0:99999:7:::
lp:\\*:\\d{5}:0:99999:7:::
sync:\\*:\\d{5}:0:99999:7:::
shutdown:\\*:\\d{5}:0:99999:7:::
halt:\\*:\\d{5}:0:99999:7:::
mail:\\*:\\d{5}:0:99999:7:::
operator:\\*:\\d{5}:0:99999:7:::
games:\\*:\\d{5}:0:99999:7:::
ftp:\\*:\\d{5}:0:99999:7:::
nobody:\\*:\\d{5}:0:99999:7:::
systemd-network:!!:\\d{5}::::::
dbus:!!:\\d{5}::::::
polkitd:!!:\\d{5}::::::
rpc:!!:\\d{5}:0:99999:7:::
abrt:!!:\\d{5}::::::
libstoragemgmt:!!:\\d{5}::::::
tcpdump:!!:\\d{5}::::::
chrony:!!:\\d{5}::::::
ntp:!!:\\d{5}::::::
tss:!!:\\d{5}::::::
sshd:!!:\\d{5}::::::
vcap:(.+):\\d{5}:1:99999:7:::
syslog:!!:\\d{5}::::::
HERE

      shadow_match_lines = shadow_match_raw.split(/\n+/).map { |l| Regexp.new("^#{l}$") }
      its(:content_as_lines) { should match_array(shadow_match_lines) }
    end

    describe file('/etc/group') do

      group_raw = <<HERE
root:x:0:
bin:x:1:
daemon:x:2:
sys:x:3:
adm:x:4:vcap
tty:x:5:
disk:x:6:
lp:x:7:
mem:x:8:
kmem:x:9:
wheel:x:10:vcap
cdrom:x:11:vcap
mail:x:12:
man:x:15:
dialout:x:18:vcap
floppy:x:19:vcap
games:x:20:
tape:x:30:
video:x:39:vcap
ftp:x:50:
lock:x:54:
audio:x:63:vcap
nobody:x:99:
users:x:100:
utmp:x:22:
utempter:x:35:
input:x:999:
systemd-journal:x:190:
systemd-network:x:192:
dbus:x:81:
polkitd:x:998:
rpc:x:32:
abrt:x:173:
libstoragemgmt:x:997:
tcpdump:x:72:
stapusr:x:156:
stapsys:x:157:
stapdev:x:158:
chrony:x:996:
slocate:x:21:
ntp:x:38:
ssh_keys:x:995:
tss:x:59:
sshd:x:74:
admin:x:994:vcap
vcap:x:1000:syslog
bosh_sshers:x:1001:vcap
bosh_sudoers:x:1002:
syslog:x:993:
HERE
      group_lines = group_raw.split(/\n+/)
      its(:content_as_lines) { should match_array(group_lines)}

    end

    describe file('/etc/gshadow') do

      gshadow_raw = <<HERE
root:*::
bin:*::
daemon:*::
sys:*::
adm:*::vcap
tty:*::
disk:*::
lp:*::
mem:*::
kmem:*::
wheel:*::vcap
cdrom:*::vcap
mail:*::
man:*::
dialout:*::vcap
floppy:*::vcap
games:*::
tape:*::
video:*::vcap
ftp:*::
lock:*::
audio:*::vcap
nobody:*::
users:*::
utmp:!::
utempter:!::
input:!::
systemd-journal:!::
systemd-network:!::
dbus:!::
polkitd:!::
rpc:!::
abrt:!::
libstoragemgmt:!::
tcpdump:!::
stapusr:!::
stapsys:!::
stapdev:!::
chrony:!::
slocate:!::
ntp:!::
ssh_keys:!::
tss:!::
sshd:!::
admin:!::vcap
vcap:!::syslog
bosh_sshers:!::vcap
bosh_sudoers:!::
syslog:!::
HERE

      gshadow_lines = gshadow_raw.split(/\n+/)
      its(:content_as_lines) { should match_array(gshadow_lines)}

    end
  end

  context 'bosh_audit_centos' do
    describe file('/etc/audit/rules.d/audit.rules') do
      its(:content) { should match /^-a always,exit -F perm=x -F auid>=500 -F auid!=4294967295 -F path=\/usr\/lib64\/dbus-1\/dbus-daemon-launch-helper -k privileged/ }
      its(:content) { should match /^-a always,exit -F perm=x -F auid>=500 -F auid!=4294967295 -F path=\/usr\/libexec\/openssh\/ssh-keysign -k privileged/ }
      its(:content) { should match /^-a always,exit -F perm=x -F auid>=500 -F auid!=4294967295 -F path=\/usr\/libexec\/sssd\/krb5_child -k privileged/ }
      its(:content) { should match /^-a always,exit -F perm=x -F auid>=500 -F auid!=4294967295 -F path=\/usr\/libexec\/sssd\/ldap_child -k privileged/ }
      its(:content) { should match /^-a always,exit -F perm=x -F auid>=500 -F auid!=4294967295 -F path=\/usr\/libexec\/sssd\/p11_child -k privileged/ }
      its(:content) { should match /^-a always,exit -F perm=x -F auid>=500 -F auid!=4294967295 -F path=\/usr\/libexec\/sssd\/proxy_child -k privileged/ }
      its(:content) { should match /^-a always,exit -F perm=x -F auid>=500 -F auid!=4294967295 -F path=\/usr\/libexec\/sssd\/selinux_child -k privileged/ }
      its(:content) { should match /^-a always,exit -F perm=x -F auid>=500 -F auid!=4294967295 -F path=\/usr\/libexec\/utempter\/utempter -k privileged/ }
    end
  end
end
