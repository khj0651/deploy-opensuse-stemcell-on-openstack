#!/bin/bash

source $(dirname $0)/../../../stemcell_builder/lib/helpers.sh

add_on_exit "false"

echo "end of script"
