# Workaround Opsfiles

The opsfile
in this directory
are meant to work around
specific issues
and are **not** meant
for general consumption.

They are intentionally
not documented or tested.

They may vanish at any time
if the issues are resolved.